import type { Metadata } from "next";
import { Suspense } from "react";
import { SearchParams } from "nuqs/server";
import { loadSearchParams } from "@/server/nuqs/NuqsLoader";
import SearchFilter from "./_components/SearchFilter";
import ProductsList, { ProductsListWrapper } from "./_components/ProductList";
import MobileSidebar from "./_components/MobileSidebar";
import TypeFilter from "./_components/filters/TypeFilter";
import CategoryFilter from "./_components/filters/CategoryFilter";
import { Filter } from "lucide-react";

export const metadata: Metadata = {
  title: "Products",  // → "Products | BNS Pharma"
  description:
    "Browse BNS Pharma's full range of pharmaceutical products — tablets, syrups, capsules, injections, ointments and drops. Available for PCD franchise and third-party manufacturing.",
  keywords: [
    "pharma products India",
    "PCD franchise products",
    "third party pharma products",
    "tablet syrup capsule manufacturer",
    "BNS Pharma products list",
  ],
  alternates: {
    canonical: "https://bnspharmaceuticals.com/products",
  },
  openGraph: {
    title: "Products | BNS Pharma",
    description:
      "Tablets, syrups, capsules, injections & more — for PCD franchise and third-party manufacturing.",
    url: "https://bnspharmaceuticals.com/products",
  },
};

type PageProps = {
  searchParams: Promise<SearchParams>;
};

const Page = async ({ searchParams }: PageProps) => {
  const { search, type, category, page } = await loadSearchParams(searchParams);
  const listKey = `${search ?? ""}-${type ?? "all"}-${category ?? "all"}-${page}`;

  return (
    // ... your existing JSX unchanged
    <div>{/* your existing layout */}</div>
  );
};

export default Page;
